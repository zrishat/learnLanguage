<template>
  <div>
    <h1> {{ this.$route.meta.title }} </h1>
    возможно в будущем...
  </div>
</template>
